package com.surveyquant.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;

                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "*/*",
                        "application/octet-stream",
                        "text/plain",
                        "text/csv",
                        "application/pdf",
                        "application/dxf",
                        "application/acad",
                        "application/x-autocad",
                        "image/*"
                });

                try {
                    startActivityForResult(i, 1001);
                } catch(Exception e){
                    uploadCallback = null;
                    return false;
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==1001 && uploadCallback!=null){
            if(c==RESULT_OK && d!=null){
                if(d.getClipData()!=null){
                    int n=d.getClipData().getItemCount();
                    Uri[] uris=new Uri[n];
                    for(int x=0;x<n;x++) uris[x]=d.getClipData().getItemAt(x).getUri();
                    uploadCallback.onReceiveValue(uris);
                } else if(d.getData()!=null){
                    uploadCallback.onReceiveValue(new Uri[]{d.getData()});
                } else {
                    uploadCallback.onReceiveValue(null);
                }
            } else {
                uploadCallback.onReceiveValue(null);
            }
            uploadCallback=null;
        }
    }

    @Override public void onBackPressed(){
        if(web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
